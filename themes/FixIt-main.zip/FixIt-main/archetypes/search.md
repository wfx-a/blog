---
title: {{ T "assets.search" }}
layout: search
date: {{ .Date }}
---
