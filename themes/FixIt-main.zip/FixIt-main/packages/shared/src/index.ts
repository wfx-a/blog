import path from 'node:path'

export const workspaceRoot = path.resolve(__dirname, '../../../')
